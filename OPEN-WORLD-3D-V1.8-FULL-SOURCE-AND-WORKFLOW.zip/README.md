OPEN WORLD 3D V1.8 - Android Godot 4.3

Upload ALL contents of this ZIP to repository ROOT (not the ZIP alone).
Keep .github/workflows/build.yml in the exact path.
Actions > Open World 3D V1.8 > Run workflow.
APK artifact: OpenWorld3D-Android-APK.
Debug signing is for testing, not Play Store release.
Build has not been verified on GitHub.
