extends Node3D

const CITY_HALF := 115.0
var player: CharacterBody3D
var car: CharacterBody3D
var camera: Camera3D
var ui: CanvasLayer
var joystick_base: Control
var joystick_knob: Control
var action_button: Button
var status_label: Label
var mission_label: Label
var money := 0
var in_car := false
var car_speed := 0.0
var yaw := 0.0
var pitch := -0.22
var move_axis := Vector2.ZERO
var touch_joystick := -1
var touch_camera := -1
var joystick_center := Vector2.ZERO
var last_camera_pos := Vector2.ZERO
var jump_queued := false
var mission_index := 0
var mission_points := [Vector3(42, 0, 42), Vector3(-42, 0, 42), Vector3(-42, 0, -42), Vector3(42, 0, -42)]
var mission_marker: MeshInstance3D
var sunlight: DirectionalLight3D
var elapsed := 0.0

func _ready() -> void:
	_build_world()
	_build_actors()
	_build_ui()
	_update_mission()

func _mat(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.95
	return m

func _box(parent: Node3D, pos: Vector3, size: Vector3, color: Color, solid := true) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	mesh.mesh = b
	mesh.material_override = _mat(color)
	mesh.position = pos
	parent.add_child(mesh)
	if solid:
		var body := StaticBody3D.new()
		mesh.add_child(body)
		var shape := CollisionShape3D.new()
		var collision := BoxShape3D.new()
		collision.size = size
		shape.shape = collision
		body.add_child(shape)
	return mesh

func _build_world() -> void:
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.53, 0.76, 0.94)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.8, 0.85, 1.0)
	e.ambient_light_energy = 0.7
	env.environment = e
	add_child(env)
	sunlight = DirectionalLight3D.new()
	sunlight.rotation_degrees = Vector3(-50, -35, 0)
	sunlight.light_energy = 1.2
	add_child(sunlight)
	_box(self, Vector3(0, -0.55, 0), Vector3(250, 1, 250), Color(0.28, 0.54, 0.31))
	for i in range(-2, 3):
		_box(self, Vector3(i * 42, 0.02, 0), Vector3(12, 0.08, 240), Color(0.16, 0.18, 0.21), false)
		_box(self, Vector3(0, 0.03, i * 42), Vector3(240, 0.08, 12), Color(0.16, 0.18, 0.21), false)
		for j in range(-10, 11):
			_box(self, Vector3(i * 42, 0.09, j * 11), Vector3(0.25, 0.02, 4.5), Color(0.95, 0.87, 0.55), false)
			_box(self, Vector3(j * 11, 0.1, i * 42), Vector3(4.5, 0.02, 0.25), Color(0.95, 0.87, 0.55), false)
	var rng := RandomNumberGenerator.new()
	rng.seed = 88192
	for x in range(-2, 2):
		for z in range(-2, 2):
			for bx in range(2):
				for bz in range(2):
					var cx := x * 42.0 + 15.0 + bx * 12.0
					var cz := z * 42.0 + 15.0 + bz * 12.0
					if absf(cx) < 12 or absf(cz) < 12:
						continue
					var h := rng.randf_range(8, 28)
					var color := Color.from_hsv(rng.randf_range(0.05, 0.65), 0.25, rng.randf_range(0.55, 0.9))
					_box(self, Vector3(cx, h / 2, cz), Vector3(9, h, 9), color)
					for level in range(2, int(h) - 1, 3):
						_box(self, Vector3(cx, level, cz + 4.52), Vector3(6.6, 1.2, 0.08), Color(0.32, 0.68, 0.82), false)
	for i in range(36):
		var px := rng.randf_range(-108, 108)
		var pz := rng.randf_range(-108, 108)
		if fmod(absf(px) + 21.0, 42.0) < 10 or fmod(absf(pz) + 21.0, 42.0) < 10:
			continue
		_box(self, Vector3(px, 1.5, pz), Vector3(0.7, 3, 0.7), Color(0.37, 0.22, 0.12), false)
		var leaves := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = 2.5
		sphere.height = 5.0
		leaves.mesh = sphere
		leaves.material_override = _mat(Color(0.12, rng.randf_range(0.4, 0.7), 0.2))
		leaves.position = Vector3(px, 4.3, pz)
		add_child(leaves)
	mission_marker = MeshInstance3D.new()
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = 1.2
	cylinder.bottom_radius = 1.2
	cylinder.height = 0.2
	mission_marker.mesh = cylinder
	mission_marker.material_override = _mat(Color(1, 0.8, 0.05))
	add_child(mission_marker)

func _actor_body(pos: Vector3, size: Vector3, color: Color) -> CharacterBody3D:
	var actor := CharacterBody3D.new()
	actor.position = pos
	add_child(actor)
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	shape.shape = box
	actor.add_child(shape)
	_box(actor, Vector3.ZERO, size, color, false)
	return actor

func _build_actors() -> void:
	player = _actor_body(Vector3(0, 1.1, 12), Vector3(0.85, 2.1, 0.7), Color(0.18, 0.48, 0.94))
	_box(player, Vector3(0, 1.35, 0), Vector3(0.7, 0.7, 0.7), Color(0.96, 0.75, 0.53), false)
	car = _actor_body(Vector3(5, 0.8, 12), Vector3(2.2, 1.4, 4), Color(0.9, 0.18, 0.16))
	_box(car, Vector3(0, 0.9, -0.2), Vector3(1.9, 0.8, 2.1), Color(0.12, 0.22, 0.32), false)
	camera = Camera3D.new()
	camera.current = true
	add_child(camera)

func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(root)
	status_label = Label.new()
	status_label.position = Vector2(22, 16)
	status_label.add_theme_font_size_override("font_size", 24)
	root.add_child(status_label)
	mission_label = Label.new()
	mission_label.position = Vector2(22, 52)
	mission_label.add_theme_font_size_override("font_size", 20)
	root.add_child(mission_label)
	joystick_base = Control.new()
	joystick_base.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	joystick_base.position = Vector2(35, -200)
	joystick_base.custom_minimum_size = Vector2(160, 160)
	root.add_child(joystick_base)
	var base := ColorRect.new()
	base.color = Color(0.1, 0.13, 0.2, 0.42)
	base.size = Vector2(160, 160)
	base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	joystick_base.add_child(base)
	joystick_knob = ColorRect.new()
	joystick_knob.color = Color(0.5, 0.8, 1, 0.85)
	joystick_knob.size = Vector2(58, 58)
	joystick_knob.position = Vector2(51, 51)
	joystick_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	joystick_base.add_child(joystick_knob)
	action_button = Button.new()
	action_button.text = "LÊN XE"
	action_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	action_button.position = Vector2(-190, -170)
	action_button.size = Vector2(150, 64)
	action_button.pressed.connect(_toggle_car)
	root.add_child(action_button)
	var jump_button := Button.new()
	jump_button.text = "NHẢY"
	jump_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	jump_button.position = Vector2(-190, -95)
	jump_button.size = Vector2(150, 62)
	jump_button.pressed.connect(func(): jump_queued = true)
	root.add_child(jump_button)

func _toggle_car() -> void:
	if in_car:
		in_car = false
		player.global_position = car.global_position + car.global_transform.basis.x * 3.2 + Vector3.UP * 1.5
		player.visible = true
		player.set_collision_layer_value(1, true)
		player.set_collision_mask_value(1, true)
	else:
		if player.global_position.distance_to(car.global_position) > 5.0:
			return
		in_car = true
		player.visible = false
		player.set_collision_layer_value(1, false)
		player.set_collision_mask_value(1, false)
	action_button.text = "XUỐNG XE" if in_car else "LÊN XE"

func _update_mission() -> void:
	mission_marker.position = mission_points[mission_index] + Vector3(0, 0.3, 0)
	mission_label.text = "Nhiệm vụ: Đến vòng vàng | Thưởng 100$"

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed:
			if t.position.x < get_viewport().get_visible_rect().size.x * 0.4 and touch_joystick == -1:
				touch_joystick = t.index
				joystick_center = joystick_base.global_position + Vector2(80, 80)
				_set_joystick(t.position)
			elif touch_camera == -1:
				touch_camera = t.index
				last_camera_pos = t.position
		else:
			if t.index == touch_joystick:
				touch_joystick = -1
				move_axis = Vector2.ZERO
				joystick_knob.position = Vector2(51, 51)
			if t.index == touch_camera:
				touch_camera = -1
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		if d.index == touch_joystick:
			_set_joystick(d.position)
		elif d.index == touch_camera:
			yaw -= d.relative.x * 0.004
			pitch = clampf(pitch - d.relative.y * 0.003, -0.85, 0.35)
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		var m := event as InputEventMouseMotion
		yaw -= m.relative.x * 0.004
		pitch = clampf(pitch - m.relative.y * 0.003, -0.85, 0.35)

func _set_joystick(pos: Vector2) -> void:
	var v := (pos - joystick_center).limit_length(65)
	move_axis = Vector2(v.x, -v.y) / 65.0
	joystick_knob.position = Vector2(51, 51) + v

func _physics_process(delta: float) -> void:
	elapsed += delta
	sunlight.rotation_degrees.x = -45.0 + sin(elapsed * 0.015) * 38.0
	var axis := move_axis
	axis.x += Input.get_axis("ui_left", "ui_right")
	axis.y += Input.get_axis("ui_down", "ui_up")
	axis = axis.limit_length(1.0)
	var forward := Vector3(-sin(yaw), 0, -cos(yaw))
	var right := Vector3(cos(yaw), 0, -sin(yaw))
	if in_car:
		car_speed = move_toward(car_speed, axis.y * 19.0, delta * 13.0)
		car.rotation.y -= axis.x * delta * 1.4 * signf(car_speed) if absf(car_speed) > 0.4 else 0.0
		car.velocity = -car.global_transform.basis.z * car_speed
		car.velocity.y -= 20 * delta
		car.move_and_slide()
	else:
		var direction := (right * axis.x + forward * axis.y).normalized()
		player.velocity.x = direction.x * 7.5
		player.velocity.z = direction.z * 7.5
		if direction.length() > 0.1:
			player.rotation.y = atan2(-direction.x, -direction.z)
		if player.is_on_floor():
			if jump_queued or Input.is_action_just_pressed("ui_accept"):
				player.velocity.y = 8.0
		else:
			player.velocity.y -= 20 * delta
		player.move_and_slide()
	jump_queued = false
	var target := car.global_position if in_car else player.global_position
	var cam_distance := 11.0 if in_car else 7.0
	var cam_height := 5.0 if in_car else 3.3
	var cam_pos := target - forward * cam_distance + Vector3(0, cam_height + pitch * 5, 0)
	camera.global_position = camera.global_position.lerp(cam_pos, minf(1.0, delta * 7))
	camera.look_at(target + Vector3(0, 1.4, 0))
	var dist := target.distance_to(mission_points[mission_index])
	if dist < 4.0:
		money += 100
		mission_index = (mission_index + 1) % mission_points.size()
		_update_mission()
	status_label.text = "OPEN WORLD 3D   |   $%d   |   %s" % [money, "LÁI XE" if in_car else "ĐI BỘ"]
	mission_label.text = "Đến điểm vàng: %dm | +100$" % int(dist)
